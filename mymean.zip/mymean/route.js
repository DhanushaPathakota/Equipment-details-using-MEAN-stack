var vcapServices = require('vcap_services');
var express = require("express");
var bodyParser = require("body-parser");
var MongoClient = require("mongodb").MongoClient;
var app = express();
let url;
var credentials = vcapServices.getCredentials('mlab');
url=credentials.uri;

if (url==null)
  url="mongodb://mongo:27017/db"
var urlencodedParser = bodyParser.urlencoded({ extended: false });

MongoClient.connect(url, {native_parser:true},{ useUnifiedTopology: true },function (err, db) {
    if(!err)
    {

    console.log("Connected to Database");


    //console.log("We are connected to the company database",url);
    app.use(express.static('public'));
    app.use(bodyParser.json());

    app.get("/", function (req, res) {
      console.log("Got a GET request for the homepage");
      res.send("<h1>Welcome to MSRIT</h1>");
    });
/*JS client side files has to be placed under a folder by name 'public' */

app.get('/index.html', function (req, res) {  
   res.sendFile( __dirname + "/" + "index.html" );    
})  

app.get('/insert.html', function (req, res) {
    res.sendFile( __dirname + "/" + "insert.html" );
})
/* to access the posted data from client using request body (POST) or request params(GET) */
//-----------------------POST METHOD-------------------------------------------------
app.post('/process_post', function (req, res) {
    /* Handling the AngularJS post request*/
    console.log(req.body);
	res.setHeader('Content-Type', 'text/html');
    /*response has to be in the form of a JSON*/
   
        /*adding a new field to send it to the angular Client */
		console.log("Sent data are (POST): Equipment ID :"+req.body.eqpid+" Equipment Name="+req.body.eqpname +"Equipment model="+req.body.model+ "Equipment type="+req.body.type+ "Equipment price="+req.body.price +"Equipment mdate=" +req.body.mdate);
		// Submit to the DB
  	var eqpid = req.body.eqpid;
    var eqpname = req.body.eqpname;
	var model = req.body.model;
	var type = req.body.type;
	var price = req.body.price;
	var mdate = req.body.mdate;
	db.collection('equipment').insert({eqpid:eqpid,eqpname:eqpname,model:model,type:type,price:price,mdate:mdate });
    res.send("Equipment Inserted-->"+JSON.stringify(req.body));
    /*Sending the respone back to the angular Client */
});

//--------------------------GET METHOD-------------------------------
app.get('/process_get', function (req, res) { 
// Submit to the DB
  var newEqp = req.query;
	var eqpid = req.query['eqpid'];
    var eqpname = req.query['eqpname'];
	var model = req.query['model'];
	var type = req.query['type']
	var price = req.query['price'];
	var mdate = req.query['mdate']
	db.collection('equipment').insert({eqpid:eqpid,eqpname:eqpname, model:model,type:type,price:price,mdate:mdate });	
    console.log("Sent data are (GET): EqpID :"+eqpid+" and Equipment name :"+eqpname+"Equipment model="+model+ "Equipment type="+type+ "Equipment price="+price +"Equipment mdate=" +mdate);
  	res.send("Equipment Inserted-->"+JSON.stringify(newEqp));
}) 

//--------------UPDATE------------------------------------------
app.get('/update.html', function (req, res) {
    res.sendFile( __dirname + "/" + "update.html" );
})

app.get("/update", function(req, res) {
  var eqpname1=req.query.eqpname;
  var neweqp=req.query.newname;

    db.collection('equipment').find({"eqpname": eqpname1}).toArray(function(err, docs) {
    if (docs.length==0) {
      res.send("Equipment doesnt exist ");
    }
     else {
      
  
	//-----------------------------------------
	db.collection('equipment', function (err, data) {
        data.update({"eqpname":eqpname1},{$set:{"eqpname":neweqp}},{multi:true},
            function(err, result){
				if (err) {
					res.send("Failed to update data.");
			} else {
				res.send(result+"\n"+"Equipment updated");
				console.log(result)
			}
        });
    });
  }
});
  })	
//--------------SEARCH------------------------------------------
app.get('/search.html', function (req, res) {  
   res.sendFile( __dirname + "/" + "search.html" );    
})

app.get("/search", function(req, res) {
	//var empidnum=parseInt(req.query.empid)  // if empid is an integer
	var eqpidnum=req.query.eqpid;
    db.collection('equipment').find({eqpid: eqpidnum}).toArray(function(err, docs) {
    if (docs.length==0) {
      res.send("Equipment doesnt exist ");
    }
     else {
      res.status(200).json(docs);
    }
  });
  });
  // --------------To find "Single Document"-------------------
	/*var empidnum=parseInt(req.query.empid)
    db.collection('employee').find({'empid':empidnum}).nextObject(function(err, doc) {
    if (err) {
      console.log(err.message+ "Failed to get data");
    } else {
      res.status(200).json(doc);
    }
  })
}); */

//--------------DELETE------------------------------------------
app.get('/delete.html', function (req, res) {  
   res.sendFile( __dirname + "/" + "delete.html" );    
})

app.get("/delete", function(req, res) {
	var eqpidnum=req.query.eqpid  // if empid is an integer
  db.collection('equipment').find({"eqpid": eqpidnum}).toArray(function(err, docs) {
    if (docs.length==0) {
      res.send("Equipment doesnt exist ");
    }
     else {
  
	db.collection('equipment', function (err, data) {
        data.remove({"eqpid":eqpidnum}, function(err, result){
				if (err) {
					res.send("Failed to remove data.");
			} else {
				res.send("Equipment Deleted Successfully");
				console.log("Equipment Deleted")
			}
        });
    });
  }
});
  });
app.get('/display', function (req, res) { 
//-----DISPLAY IN JSON FORMAT  -------------------------
/*db.collection('employee').find({}).toArray(function(err, docs) {
    if (err) {
      console.log("Failed to get data.");
    } else 
	{
		res.status(200).json(docs);
    }
  });*/
//-------------DISPLAY USING EMBEDDED JS -----------
 db.collection('equipment').find().sort({eqpid:1}).toArray(
 		function(err , i){
        if (err) return console.log(err)
        res.render('disp.ejs',{equipment: i})  
     })
//---------------------// sort({empid:-1}) for descending order -----------//
}) 
app.get('/about', function (req, res) {  
   console.log("Got a GET request for /about");  
   res.send('This is a equipment company');  
})  
 
var server = app.listen(8080, function () {
  var host = server.address().address
  var port = server.address().port
  console.log("MEAN Stack app listening at http://%s:%s", host, port)
  })

}
else {

console.log("not connected",url);
//db.close()

}

});

